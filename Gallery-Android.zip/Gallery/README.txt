Ad-free gallery. No INTERNET permission, so no ads or tracking are possible.
