package com.clear.gallery

import android.app.Activity
import android.app.AlertDialog
import android.app.Dialog
import android.content.ContentUris
import android.content.ContentValues
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.media.MediaMuxer
import android.media.ThumbnailUtils
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.text.InputType
import android.util.LruCache
import android.util.Size
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.view.ViewGroup
import android.widget.AbsListView
import android.widget.ArrayAdapter
import android.widget.BaseAdapter
import android.widget.CheckBox
import android.widget.SeekBar
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.GridView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.MediaController
import android.widget.TextView
import android.widget.Toast
import android.widget.VideoView
import java.io.File
import java.nio.ByteBuffer
import java.util.concurrent.Executors

class Item(val uri: Uri, val video: Boolean, val bucket: String, val date: Long, val name: String, val dur: Long, val file: File? = null)

class MainActivity : Activity() {
    private val ex = Executors.newFixedThreadPool(3)
    private val ui = Handler(Looper.getMainLooper())
    private val cache = LruCache<String, Bitmap>(200)
    private lateinit var sp: SharedPreferences
    private lateinit var content: FrameLayout
    private lateinit var title: TextView
    private lateinit var tabs: LinearLayout
    private lateinit var main: LinearLayout
    private var all = listOf<Item>()
    private var tab = 0
    private var album: String? = null
    private var hid = false
    private var viewer: Dialog? = null
    private val bgs = intArrayOf(0xFF000000.toInt(), 0xFF050B1A.toInt(), 0xFF121212.toInt())

    private fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        sp = getSharedPreferences("g", MODE_PRIVATE)
        main = LinearLayout(this)
        main.orientation = LinearLayout.VERTICAL
        val top = LinearLayout(this)
        top.gravity = Gravity.CENTER_VERTICAL
        top.setPadding(dp(16), dp(36), dp(8), dp(8))
        title = TextView(this)
        title.textSize = 22f
        title.setTextColor(Color.WHITE)
        title.typeface = Typeface.DEFAULT_BOLD
        top.addView(title, LinearLayout.LayoutParams(0, -2, 1f))
        val gear = TextView(this)
        gear.text = "⚙"
        gear.textSize = 24f
        gear.setTextColor(Color.WHITE)
        gear.setPadding(dp(14), dp(4), dp(14), dp(4))
        gear.setOnClickListener { settings() }
        top.addView(gear)
        content = FrameLayout(this)
        tabs = LinearLayout(this)
        listOf("All", "Photos", "Videos", "Albums").forEachIndexed { i, s ->
            val t = TextView(this)
            t.text = s
            t.gravity = Gravity.CENTER
            t.textSize = 14f
            t.setPadding(0, dp(14), 0, dp(14))
            t.setOnClickListener { tab = i; album = null; hid = false; render() }
            tabs.addView(t, LinearLayout.LayoutParams(0, -2, 1f))
        }
        main.addView(top)
        main.addView(content, LinearLayout.LayoutParams(-1, 0, 1f))
        main.addView(tabs)
        setContentView(main)
        render()
        val perms = if (Build.VERSION.SDK_INT >= 33) arrayOf("android.permission.READ_MEDIA_IMAGES", "android.permission.READ_MEDIA_VIDEO") else arrayOf("android.permission.READ_EXTERNAL_STORAGE")
        if (perms.all { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }) load() else requestPermissions(perms, 1)
    }

    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, r: IntArray) {
        if (r.isNotEmpty() && r.all { it == 0 }) load()
    }

    override fun onActivityResult(c: Int, r: Int, d: Intent?) {
        if (c == 11) { viewer?.dismiss(); load() }
    }

    override fun onBackPressed() {
        if (hid || album != null) { hid = false; album = null; render() } else super.onBackPressed()
    }

    private fun load() {
        ex.execute {
            val out = ArrayList<Item>()
            val proj = arrayOf("_id", "media_type", "bucket_display_name", "date_added", "_display_name", "duration")
            contentResolver.query(MediaStore.Files.getContentUri("external"), proj, "media_type IN (1,3)", null, null)?.use { c ->
                while (c.moveToNext()) {
                    val v = c.getInt(1) == 3
                    val base = if (v) MediaStore.Video.Media.EXTERNAL_CONTENT_URI else MediaStore.Images.Media.EXTERNAL_CONTENT_URI
                    out.add(Item(ContentUris.withAppendedId(base, c.getLong(0)), v, c.getString(2) ?: "Other", c.getLong(3), c.getString(4) ?: "file", c.getLong(5)))
                }
            }
            ui.post { all = out; render() }
        }
    }

    private fun items(): List<Item> {
        val l: List<Item> = when {
            hid -> (File(filesDir, "hidden").listFiles() ?: emptyArray()).map { f ->
                Item(Uri.fromFile(f), f.extension.lowercase() in setOf("mp4", "mkv", "3gp", "webm", "mov"), "Hidden", f.lastModified() / 1000, f.name, 0, f)
            }
            album != null -> all.filter { it.bucket == album }
            tab == 1 -> all.filter { !it.video }
            tab == 2 -> all.filter { it.video }
            else -> all
        }
        return when (sp.getInt("sort", 0)) {
            1 -> l.sortedBy { it.date }
            2 -> l.sortedBy { it.name.lowercase() }
            else -> l.sortedByDescending { it.date }
        }
    }

    private fun dur(ms: Long): String { val s = ms / 1000; return "%d:%02d".format(s / 60, s % 60) }

    private fun thumb(m: Item, px: Int): Bitmap? = try {
        val f = m.file
        if (f == null) contentResolver.loadThumbnail(m.uri, Size(px, px), null)
        else if (m.video) ThumbnailUtils.createVideoThumbnail(f, Size(px, px), null)
        else {
            val o = BitmapFactory.Options()
            o.inJustDecodeBounds = true
            BitmapFactory.decodeFile(f.path, o)
            val q = BitmapFactory.Options()
            q.inSampleSize = maxOf(1, o.outWidth / px)
            BitmapFactory.decodeFile(f.path, q)
        }
    } catch (e: Exception) { null }

    private fun render() {
        main.setBackgroundColor(bgs[sp.getInt("bg", 1)])
        for (i in 0 until tabs.childCount) (tabs.getChildAt(i) as TextView).setTextColor(if (i == tab) 0xFF4DA3FF.toInt() else 0xFF8899BB.toInt())
        content.removeAllViews()
        val names = arrayOf("Gallery", "Photos", "Videos", "Albums")
        title.text = if (hid) "🔒 Hidden" else (album ?: names[tab])
        if (tab == 3 && album == null && !hid) { albums(); return }
        val list = items()
        val cols = sp.getInt("cols", 3)
        val size = resources.displayMetrics.widthPixels / cols
        val g = GridView(this)
        g.numColumns = cols
        g.adapter = object : BaseAdapter() {
            override fun getCount() = list.size
            override fun getItem(i: Int) = list[i]
            override fun getItemId(i: Int) = i.toLong()
            override fun getView(i: Int, v: View?, parent: ViewGroup?): View {
                val f = (v as? FrameLayout) ?: FrameLayout(this@MainActivity).also { fl ->
                    val img = ImageView(this@MainActivity)
                    img.scaleType = ImageView.ScaleType.CENTER_CROP
                    fl.addView(img, FrameLayout.LayoutParams(-1, -1))
                    val tv = TextView(this@MainActivity)
                    tv.setTextColor(Color.WHITE)
                    tv.textSize = 11f
                    tv.setPadding(dp(4), 0, dp(4), 0)
                    tv.setBackgroundColor(0x88000000.toInt())
                    fl.addView(tv, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.START))
                }
                f.layoutParams = AbsListView.LayoutParams(size, size)
                val iv = f.getChildAt(0) as ImageView
                val tv = f.getChildAt(1) as TextView
                val m = list[i]
                tv.visibility = if (m.video) View.VISIBLE else View.GONE
                tv.text = "▶ " + dur(m.dur)
                val key = m.uri.toString()
                iv.tag = key
                val hit = cache.get(key)
                if (hit != null) iv.setImageBitmap(hit) else {
                    iv.setImageDrawable(null)
                    ex.execute {
                        val bm = thumb(m, 300)
                        if (bm != null) { cache.put(key, bm); ui.post { if (iv.tag == key) iv.setImageBitmap(bm) } }
                    }
                }
                return f
            }
        }
        g.setOnItemClickListener { _, _, i, _ -> open(list, i) }
        content.addView(g)
    }

    private fun albums() {
        val groups = all.groupBy { it.bucket }.toList().sortedByDescending { it.second.size }
        val names = listOf("🔒 Hidden") + groups.map { it.first + "  (" + it.second.size + ")" }
        val lv = ListView(this)
        lv.adapter = object : ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, names) {
            override fun getView(i: Int, v: View?, p: ViewGroup): View {
                val t = super.getView(i, v, p) as TextView
                t.setTextColor(Color.WHITE)
                t.setPadding(dp(16), dp(14), dp(16), dp(14))
                return t
            }
        }
        lv.setOnItemClickListener { _, _, i, _ -> if (i == 0) askPin() else { album = groups[i - 1].first; render() } }
        content.addView(lv)
    }

    private fun askPin() {
        val saved = sp.getString("pin", null)
        val e = EditText(this)
        e.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
        e.hint = if (saved == null) "புதிய PIN (4+ இலக்கம்)" else "PIN"
        AlertDialog.Builder(this).setTitle("Hidden").setView(e).setPositiveButton("OK") { _, _ ->
            val t = e.text.toString()
            if (saved == null) {
                if (t.length >= 4) { sp.edit().putString("pin", t).apply(); hid = true; render() } else toast("குறைந்தது 4 இலக்கம்")
            } else if (t == saved) { hid = true; render() } else toast("தவறான PIN")
        }.show()
    }

    private fun settings() {
        val cols = sp.getInt("cols", 3)
        val sort = sp.getInt("sort", 0)
        val bg = sp.getInt("bg", 1)
        val opts = arrayOf("Columns: $cols", "Sort: " + arrayOf("Newest", "Oldest", "Name")[sort], "Background: " + arrayOf("Black", "Navy", "Grey")[bg], "Reset hidden PIN")
        AlertDialog.Builder(this).setTitle("Settings").setItems(opts) { _, w ->
            when (w) {
                0 -> sp.edit().putInt("cols", if (cols >= 5) 2 else cols + 1).apply()
                1 -> sp.edit().putInt("sort", (sort + 1) % 3).apply()
                2 -> sp.edit().putInt("bg", (bg + 1) % 3).apply()
                else -> { sp.edit().remove("pin").apply(); toast("அடுத்த முறை புது PIN வைக்கலாம்") }
            }
            render()
            if (w < 3) settings()
        }.show()
    }

    private fun open(list: List<Item>, start: Int) {
        var cur = start
        var sc = 1f
        val d = Dialog(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen)
        viewer = d
        val root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)
        val iv = ImageView(this)
        val vv = VideoView(this)
        root.addView(iv, FrameLayout.LayoutParams(-1, -1))
        root.addView(vv, FrameLayout.LayoutParams(-1, -1, Gravity.CENTER))
        val info = TextView(this)
        info.setTextColor(Color.WHITE)
        info.setPadding(dp(16), dp(36), 0, 0)
        val bar = LinearLayout(this)
        bar.setBackgroundColor(0x99000000.toInt())
        root.addView(info)
        root.addView(bar, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))

        fun show() {
            val m = list[cur]
            sc = 1f; iv.scaleX = 1f; iv.scaleY = 1f
            info.text = "${cur + 1}/${list.size}  ${m.name}"
            vv.stopPlayback()
            if (m.video) {
                iv.visibility = View.GONE
                vv.visibility = View.VISIBLE
                vv.setMediaController(MediaController(this))
                vv.setVideoURI(m.uri)
                vv.start()
            } else {
                vv.visibility = View.GONE
                iv.visibility = View.VISIBLE
                iv.setImageDrawable(null)
                ex.execute { val bm = thumb(m, 2000); ui.post { if (list[cur] === m) iv.setImageBitmap(bm) } }
            }
        }

        fun btn(t: String, a: () -> Unit) {
            val b = TextView(this)
            b.text = t
            b.textSize = 20f
            b.setTextColor(Color.WHITE)
            b.gravity = Gravity.CENTER
            b.setPadding(0, dp(14), 0, dp(14))
            b.setOnClickListener { a() }
            bar.addView(b, LinearLayout.LayoutParams(0, -2, 1f))
        }
        btn("📤") { share(list[cur]) }
        btn("HD") { moveHd(list[cur]) }
        btn("✂") { trim(list[cur]) { ms -> vv.seekTo(ms) } }
        btn("🔒") { hideToggle(list[cur]) }
        btn("🗑") { del(list[cur]) }

        val sg = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(s: ScaleGestureDetector): Boolean {
                sc = (sc * s.scaleFactor).coerceIn(1f, 5f)
                iv.scaleX = sc; iv.scaleY = sc
                return true
            }
        })
        val gd = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true
            override fun onFling(a: MotionEvent?, b: MotionEvent, vx: Float, vy: Float): Boolean {
                if (sc > 1f) return false
                if (vx < -800 && cur < list.size - 1) { cur++; show() } else if (vx > 800 && cur > 0) { cur--; show() }
                return true
            }
        })
        root.setOnTouchListener { _, e -> sg.onTouchEvent(e); if (!sg.isInProgress) gd.onTouchEvent(e); true }
        d.setContentView(root)
        d.setOnDismissListener { vv.stopPlayback(); viewer = null }
        d.show()
        show()
    }

    private fun share(m: Item) {
        if (m.file != null) { toast("Hidden ஃபைலை ஷேர் பண்ண முடியாது"); return }
        val i = Intent(Intent.ACTION_SEND).setType(if (m.video) "video/*" else "image/*").putExtra(Intent.EXTRA_STREAM, m.uri)
        startActivity(Intent.createChooser(i, null))
    }

    private fun copyTo(m: Item, folder: String): Boolean = try {
        val dflt = if (m.video) "video/mp4" else "image/jpeg"
        val mime = if (m.file != null) dflt else (contentResolver.getType(m.uri) ?: dflt)
        val cv = ContentValues()
        cv.put(MediaStore.MediaColumns.DISPLAY_NAME, m.name)
        cv.put(MediaStore.MediaColumns.MIME_TYPE, mime)
        cv.put(MediaStore.MediaColumns.RELATIVE_PATH, (if (m.video) "Movies/" else "Pictures/") + folder)
        val coll = if (m.video) MediaStore.Video.Media.EXTERNAL_CONTENT_URI else MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        val dst = contentResolver.insert(coll, cv)!!
        contentResolver.openInputStream(m.uri)!!.use { i -> contentResolver.openOutputStream(dst)!!.use { o -> i.copyTo(o) } }
        true
    } catch (e: Exception) { false }

    private fun moveHd(m: Item) {
        ex.execute {
            val ok = copyTo(m, "HD")
            ui.post { if (ok) { toast("HD ஃபோல்டருக்கு காப்பி ஆச்சு"); if (m.file == null) del(m) } else toast("மூவ் ஆகலை") }
        }
    }

    private fun hideToggle(m: Item) {
        ex.execute {
            val f = m.file
            val ok = if (f != null) copyTo(m, "Restored").also { if (it) f.delete() } else try {
                val dir = File(filesDir, "hidden"); dir.mkdirs()
                contentResolver.openInputStream(m.uri)!!.use { i -> File(dir, m.name).outputStream().use { o -> i.copyTo(o) } }
                true
            } catch (e: Exception) { false }
            ui.post {
                if (!ok) toast("ஆகலை")
                else if (f != null) { viewer?.dismiss(); load(); render() }
                else del(m)
            }
        }
    }

    private fun trim(m: Item, seek: (Int) -> Unit) {
        if (!m.video) { toast("வீடியோவுக்கு மட்டும்"); return }
        var total = 0L
        var base = 0
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(this, m.uri)
            total = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)!!.toLong()
            base = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toInt() ?: 0
        } catch (e: Exception) { toast("இந்த வீடியோ ஓபன் ஆகலை"); return } finally { r.release() }
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(20), dp(10), dp(20), 0)
        val lab = TextView(this)
        val s1 = SeekBar(this)
        s1.max = total.toInt(); s1.progress = 0
        val s2 = SeekBar(this)
        s2.max = total.toInt(); s2.progress = total.toInt()
        val mute = CheckBox(this)
        mute.text = "Mute (ஒலி நீக்கு)"
        val rot = CheckBox(this)
        rot.text = "Rotate 90°"
        fun upd() { lab.text = "Start " + dur(s1.progress.toLong()) + "  →  End " + dur(s2.progress.toLong()) }
        upd()
        val l = object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, p: Int, u: Boolean) { upd(); if (u) seek(p) }
            override fun onStartTrackingTouch(s: SeekBar) {}
            override fun onStopTrackingTouch(s: SeekBar) {}
        }
        s1.setOnSeekBarChangeListener(l)
        s2.setOnSeekBarChangeListener(l)
        box.addView(lab); box.addView(s1); box.addView(s2); box.addView(mute); box.addView(rot)
        val tot = total
        val b0 = base
        AlertDialog.Builder(this).setTitle("✂ Video Edit").setView(box)
            .setPositiveButton("Save") { _, _ ->
                val a = s1.progress.toLong()
                val z = s2.progress.toLong()
                if (z - a < 500) { toast("End, Start-ஐ விட பெரிசா இருக்கணும்"); return@setPositiveButton }
                toast("சேமிக்கிறது...")
                ex.execute {
                    val ok = trimVideo(m, a, minOf(z, tot), mute.isChecked, (b0 + if (rot.isChecked) 90 else 0) % 360)
                    ui.post { toast(if (ok) "Movies/Edited-ல சேவ் ஆச்சு" else "எடிட் ஆகலை"); load() }
                }
            }.setNegativeButton("Cancel", null).show()
    }

    private fun trimVideo(m: Item, s: Long, e: Long, mute: Boolean, rot: Int): Boolean = try {
        val tmp = File(cacheDir, "trim.mp4")
        val ext = MediaExtractor()
        ext.setDataSource(this, m.uri, null)
        val mux = MediaMuxer(tmp.path, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        val map = HashMap<Int, Int>()
        for (i in 0 until ext.trackCount) {
            val fmt = ext.getTrackFormat(i)
            val mi = fmt.getString(MediaFormat.KEY_MIME) ?: ""
            if (mi.startsWith("video") || (mi.startsWith("audio") && !mute)) { map[i] = mux.addTrack(fmt); ext.selectTrack(i) }
        }
        mux.setOrientationHint(rot)
        mux.start()
        ext.seekTo(s * 1000, MediaExtractor.SEEK_TO_PREVIOUS_SYNC)
        val buf = ByteBuffer.allocate(4 * 1024 * 1024)
        val info = MediaCodec.BufferInfo()
        var first = -1L
        while (true) {
            val n = ext.readSampleData(buf, 0)
            if (n < 0) break
            val t = ext.sampleTime
            if (t > e * 1000) break
            if (first < 0) first = t
            val key = if ((ext.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC) != 0) MediaCodec.BUFFER_FLAG_KEY_FRAME else 0
            info.set(0, n, maxOf(0L, t - first), key)
            mux.writeSampleData(map[ext.sampleTrackIndex]!!, buf, info)
            ext.advance()
        }
        mux.stop(); mux.release(); ext.release()
        saveVideo(tmp)
    } catch (ex2: Exception) { false }

    private fun saveVideo(f: File): Boolean = try {
        val cv = ContentValues()
        cv.put(MediaStore.MediaColumns.DISPLAY_NAME, "edit_" + System.currentTimeMillis() + ".mp4")
        cv.put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
        cv.put(MediaStore.MediaColumns.RELATIVE_PATH, "Movies/Edited")
        val dst = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, cv)!!
        f.inputStream().use { i -> contentResolver.openOutputStream(dst)!!.use { o -> i.copyTo(o) } }
        f.delete()
        true
    } catch (e: Exception) { false }

    private fun del(m: Item) {
        val f = m.file
        if (f != null) { f.delete(); viewer?.dismiss(); render(); return }
        try {
            if (Build.VERSION.SDK_INT >= 30) startIntentSenderForResult(MediaStore.createDeleteRequest(contentResolver, listOf(m.uri)).intentSender, 11, null, 0, 0, 0)
            else { contentResolver.delete(m.uri, null, null); viewer?.dismiss(); load() }
        } catch (e: Exception) { toast("Delete ஆகலை") }
    }
}
